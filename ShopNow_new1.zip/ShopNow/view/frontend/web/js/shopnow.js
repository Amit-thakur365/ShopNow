define([
    'jquery'
], function ($) {
    "use strict";
    return function (config, element) {
        $(element).click(function () {
            var form = $(config.form);
            var bluethinkBaseUrl = form.attr('action');
            var bluethinkShopNowUrl='';
            var bluethinkCartUrl = 'checkout/cart/add';
            var bluethinkShopNowCartUrl = 'shopnow/cart/add';
            if(bluethinkBaseUrl.includes('checkout')){
                bluethinkShopNowUrl = bluethinkBaseUrl.replace(bluethinkCartUrl, bluethinkShopNowCartUrl);
            }
            if(bluethinkShopNowUrl){
                form.attr('action', bluethinkShopNowUrl);
            }
            form.trigger('submit');
            form.attr('action', bluethinkBaseUrl);
            return false;
        });
    }
});
