<?php

namespace Bluethinkinc\ShopNow\ViewModel;

use Bluethinkinc\ShopNow\Model\Config\Provider;
use Magento\Framework\View\Element\Block\ArgumentInterface;

/**
 * Class ShopNowViewModel
 * 
 * To render methods for config values on template
 */
class ShopNowViewModel implements ArgumentInterface
{
    /**
     * @var Provider
     */
    protected $provider;

    /**
     * constructor.
     * 
     * @param Provider $provider
     */
    public function __construct(
        Provider $provider
    ) {
        $this->provider = $provider;
    }

    /**
     * moduleQuestionAnswerEnable method returns module config value
     * @return int
     */

    public function isModuleShopNowEnable()
    {
        return $this->provider->isModuleEnable();
    }

    /**
     * isVisibleOnCatalogCategory method returns visible catalog category config value
     * @return int
     */
    public function isVisibleOnCategory()
    {
        return $this->provider->isVisibleOnCatalogCategory();
    }

    /**
     * isVisibleOnProductDeatil method returns visible product detail config value
     * @return int
     */
    public function isVisibleOnProductDetail()
    {
        return $this->provider->isVisibleOnProductDeatilPage();
    }
}
