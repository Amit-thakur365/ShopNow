<?php
/**
 *
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Bluethinkinc\ShopNow\Controller\Cart;

use Magento\Checkout\Model\Cart as CustomerCart;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\ResultInterface;
use Magento\Store\Model\StoreManagerInterface;
use Zend_Filter_LocalizedToNormalized;
use Magento\Checkout\Controller\Cart\Add as AddCart;
use Magento\Framework\Locale\ResolverInterface;
use Magento\Framework\Escaper;
use Magento\Checkout\Helper\Cart;
use Psr\Log\LoggerInterface;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Catalog\Api\ProductRepositoryInterface;

/**
 * Add Class Controller for processing add to cart action.
 *
 */
class Add extends AddCart
{

    private ResolverInterface $resolverInterface;
    private StoreManagerInterface $storeManager;
    private Escaper $escaper;
    private Cart $cartHelper;
    private LoggerInterface $logger;

    protected $messageManager;

    /**
     * @param ResolverInterface $resolverInterface
     * @param StoreManagerInterface $storeManager
     * @param Escaper $escaper
     * @param Cart $cartHelper
     * @param LoggerInterface $logger
     * @param Context $context
     * @param ScopeConfigInterface $scopeConfig
     */
    public function __construct(
        ResolverInterface $resolverInterface,
        StoreManagerInterface $storeManager,
        Escaper $escaper,
        Cart $cartHelper,
        LoggerInterface $logger,
        Context $context,
        ScopeConfigInterface $scopeConfig,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Framework\Data\Form\FormKey\Validator $formKeyValidator,
        CustomerCart $cart,
        ProductRepositoryInterface $productRepository
    ) {
        parent::__construct(
            $context,
            $scopeConfig,
            $checkoutSession,
            $storeManager,
            $formKeyValidator,
            $cart,
            $productRepository
        );
        $this->resolverInterface = $resolverInterface;
        $this->storeManager = $storeManager;
        $this->escaper = $escaper;
        $this->cartHelper = $cartHelper;
        $this->logger = $logger;
        $this->messageManager = $context->getMessageManager();
        $this->productRepository = $productRepository;
    }
    /**
     * Add product to shopping cart action
     *
     * @return ResponseInterface|ResultInterface
     */
    public function execute()
    {
        if (!$this->_formKeyValidator->validate($this->getRequest())) {
            $this->messageManager->addErrorMessage(
                __('Your session has expired')
            );
            return $this->resultRedirectFactory->create()->setPath('*/*/');
        }

        $params = $this->getRequest()->getParams();
        try {
            if (isset($params['qty'])) {
                $filter = new Zend_Filter_LocalizedToNormalized(
                    ['locale' => $this->resolverInterface->getLocale()]
                );
                $params['qty'] = $filter->filter($params['qty']);
            }

            $product = $this->_initProduct();
            $related = $this->getRequest()->getParam('related_product');

            /** Check product availability */

            if (!$product) {
                return $this->goBack();
            }

            $productsInCart = 1;

            /** Remove if there is no Products in cart */

            $this->cart->addProduct($product, $params);
            if (!empty($related)) {
                $this->cart->addProductsByIds(explode(',', $related));
            }

            $this->cart->save();

            /**
             * @todo remove wishlist observer \Magento\Wishlist\Observer\AddToCart
             */
            $this->_eventManager->dispatch(
                'checkout_cart_add_product_complete',
                ['product' => $product, 'request' => $this->getRequest(), 'response' => $this->getResponse()]
            );

            if (!$this->_checkoutSession->getNoCartRedirect(true)) {
                $baseUrl = $this->storeManager->getStore()->getBaseUrl();
                return $this->goBack($baseUrl.'checkout/', $product);
            }

        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            if ($this->_checkoutSession->getUseNotice(true)) {
                $this->messageManager->addNotice(
                    $this->escaper->escapeHtml($e->getMessage())
                );
            } else {
                $messages = array_unique(explode("\n", $e->getMessage()));
                foreach ($messages as $message) {
                    $this->messageManager->addError(
                        $this->escaper->escapeHtml($message)
                    );
                }
            }
            $url = $this->_checkoutSession->getRedirectUrl(true);

            if (!$url) {
                $cartUrl = $this->cartHelper->getCartUrl();
                $url = $this->_redirect->getRedirectUrl($cartUrl);
            }

            return $this->goBack($url);

        } catch (\Exception $e) {
            $this->messageManager->addException($e, __('We can\'t add this item to your shopping cart right now.'));
            $this->logger->critical($e);
            return $this->goBack();
        }
    }
}
