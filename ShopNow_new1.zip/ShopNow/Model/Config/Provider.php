<?php
/**
 * Copyright © BluethinkInc All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Bluethinkinc\ShopNow\Model\Config;

use Magento\Store\Model\ScopeInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;

/**
 * Class Provider to fetch config value
 */
class Provider
{
    /**
     * Path to the values in the config
     */
    public const ENABLE_DISABLE ='shopnow/general/enable';

    public const VISIBLE_ON_CATALOG_CATEGORY ='shopnow/more_configurations/catalog_category';

    public const VISIBLE_ON_PRODUCT_DETAIL ='shopnow/more_configurations/product_detail';
    
    /**
     * @var ScopeConfigInterface
     */
    private $scopeConfig;

    /**
     * @var StoreManagerInterface
     */
    private $storeManager;

    /**
     * Provider Constructor
     *
     * @param ScopeConfigInterface $scopeConfig
     * @param StoreManagerInterface $storeManager
     */
    public function __construct(
        ScopeConfigInterface $scopeConfig,
        StoreManagerInterface $storeManager
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->storeManager = $storeManager;
    }

    /**
     * IsModuleEnable Method returning config value
     *
     * @return int
     */
    public function isModuleEnable()
    {
        return $this->scopeConfig->getValue(
            self::ENABLE_DISABLE,
            ScopeInterface::SCOPE_STORE,
            $this->storeManager->getStore()->getId()
        );
    }

    /**
     * IsVisibleOnCatalogCategory Method returning config value
     *
     * @return int
     */
    public function isVisibleOnCatalogCategory()
    {
        return $this->scopeConfig->getValue(
            self::VISIBLE_ON_CATALOG_CATEGORY,
            ScopeInterface::SCOPE_STORE,
            $this->storeManager->getStore()->getId()
        );
    }

    /**
     * IsVisibleOnProductDeatil Method returning config value
     *
     * @return int
     */
    public function isVisibleOnProductDeatilPage()
    {
        return $this->scopeConfig->getValue(
            self::VISIBLE_ON_PRODUCT_DETAIL,
            ScopeInterface::SCOPE_STORE,
            $this->storeManager->getStore()->getId()
        );
    }
}

